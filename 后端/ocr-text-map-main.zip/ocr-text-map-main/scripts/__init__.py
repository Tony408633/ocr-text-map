"""Local validation utilities."""
